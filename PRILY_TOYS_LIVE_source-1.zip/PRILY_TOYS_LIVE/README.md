# PRILY TOYS LIVE

Aplikasi Android offline-first untuk mencatat klaim pembeli saat TikTok LIVE.

## Fitur versi awal
- Input barang LIVE: nama barang, stok, harga.
- Baris klaim pembeli: NAMA, JUMLAH, NOTES (teks bebas; koma dan angka diperbolehkan).
- Peringatan jika total klaim melebihi stok, tetapi tetap boleh disimpan.
- Pembeli yang sama digabung ke nota aktif yang belum lunas.
- Jika nota sudah lunas, transaksi LIVE berikutnya membuat nota baru.
- Rekap per tanggal, rekap total pembeli, daftar nota, riwayat LIVE.
- Edit nota, tambah/hapus barang, catat pembayaran.
- Cetak nota dengan layout konten 76 mm dan tanggal/jam saat dicetak.
- Backup dan restore JSON.

## Membuat APK melalui GitHub Actions
1. Buat repository GitHub baru, misalnya `prily-toys-live`.
2. Ekstrak ZIP ini di komputer/HP, lalu unggah **isi folder** ke repository (pastikan folder `.github` ikut terunggah).
3. Pastikan branch utama bernama `main`.
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build PRILY TOYS LIVE APK**, lalu tekan **Run workflow**. Workflow juga berjalan otomatis saat ada push ke `main`.
6. Setelah selesai, buka hasil workflow dan unduh artifact **PRILY-TOYS-LIVE-APK**.
7. Ekstrak artifact, lalu pasang `app-debug.apk` di Android. Jika Android menolak, izinkan instalasi dari sumber yang digunakan untuk membuka APK.

## Catatan penting
- Versi ini menyimpan data secara lokal pada perangkat. Jangan hapus data aplikasi sebelum membuat backup.
- Backup/restore tersedia di menu LAINNYA.
- Sinkronisasi HP kedua, overlay TikTok, pembacaan komentar otomatis, dan koneksi langsung printer Bluetooth belum termasuk versi awal.
- Cetak memakai dialog cetak Android/WebView. Dukungan dan hasil akhir 76 mm perlu diuji dengan model printer yang digunakan; pilih ukuran kertas yang sesuai pada driver/dialog printer.
- APK debug dari GitHub Actions belum ditandatangani sebagai rilis Play Store.
